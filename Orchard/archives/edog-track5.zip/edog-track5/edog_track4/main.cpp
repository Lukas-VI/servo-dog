﻿#include "lcmutil.h"
#include <QThread>
#include <stdio.h>
//#include <QDebug>
//#include <opencv2/opencv.hpp>
#include <vector>
#include <unistd.h>
#include <QDebug>
#include <QTime>
#include <sys/time.h>
#include <colorgroup.h>
#include <QTimer>
#include <pthread.h>
#include "mythread.h"
#include <QDir>
#include <wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <QThread>
#include "udputil.h"
#include "bridge.h"

extern int time_counter = 0;

//#define Bridge_flag 1  //0--手动干预，直行通过双边桥    1-- 直接识别蓝色然后二值化黑色条带

//using namespace cv;
using namespace std;
VideoCapture cap;//摄像头实例化
myThread mythread;//实例化计时线程
colorGroup colorgroup;//实例化色彩阈值类
LcmUtil *lcmutil;//创建lcm communication module
UdpUtil udpsocket;
QString residenceColor = "purple";
QString roadColor = "null";
QString nextColor = "null";//next scanne color//red


//图像处理
void imageProcess(Mat &image);

//打印程序运行模式
void logMode();

void track_run(Mat &matBlur, Mat &matEdges);

void track_run_right(Mat &matBlur, Mat &matEdges);

void track_run_left(Mat &matBlur, Mat &matEdges);

int solve_avg(Mat &matBlur, Mat &matEdges);

void Color_deal(Mat &img, int color);

void right();
//void Bridge_run(Mat &img);

void show_send_picture();

//程序入口
int main(int argc, char *argv[]) {
    //init lcm module
    time_counter = 0;
    lcmutil = new LcmUtil();
    //定义一幅图像
    Mat srcImage;
    /*以下程序用于根据输入参数的选择更改运行模式，以及选择是否将图像发送至上位机*/
    //according to the parameters passed in,choose mode
    //inputParameters1与inputParameters2是输入的两个参数
    QString inputParameters1;
    QString inputParameters2;
    QString inputParameters3;
    bool flag = true;
    //无参数输入
    if (argc == 1) {

        printf("mode is stop\n");
        mythread.Mode = myThread::stop;
        residenceColor = "null";//"red";
    }
        //输入参数大于等于两个
    else if (argc >= 2) {
        inputParameters1 = argv[1];
        //track 模式
        if (inputParameters1 == "track") {
            printf("mode is track\n");
            printf("default residenceColor is null\n");
            mythread.Mode = myThread::track;
        } else if (inputParameters1 == "purple") {
            printf("mode is track\n");
            printf("input residenceColor is purple\n");
            mythread.Mode = myThread::track;
            residenceColor = "purple";
            nextColor = "green";
        } else if (inputParameters1 == "brown") {
            printf("mode is track\n");
            printf("input residenceColor is brown\n");
            mythread.Mode = myThread::track;
            residenceColor = "brown";
            nextColor = "green";
        } else if (inputParameters1 == "stop") {
            printf("mode is stop\n");
            mythread.Mode = myThread::stop;
        } else {
            mythread.Mode = myThread::track;
            printf("parameters error\n");
            printf("mode is track\n");
        }
        //输入第2个参数
        if (argc == 3) {
            inputParameters2 = argv[2];
            if (inputParameters2 == "showImage") {
                printf("start to show image\n");
                flag = true;
                udpsocket.start();//thread2
            }
        }
    }

    //识别id为0到3的设备序号，查看是否能打开对应的摄像头
    //打开摄像头
    for (int i = 0; i <= 3; i++) {
        cap.open(i);//open device
        if (!cap.isOpened()) {
            printf("打开摄像头失败:number=%d\n", i);
            if (i == 3)
                return 0;
        } else {
            printf("打开摄像头成功:number=%d\n", i);
            break;
        }
    }

    //计时线程开启
    mythread.start();
    //如下三行用于获取非阻塞获取键盘输入，中断程序的运行
    //get keyboard to stop program

    char buf[5] = {0};//keyboard buffer
    int attr = 1;
    ioctl(STDIN_FILENO, FIONBIO, &attr);//set non-blocking flag

    //主循环
    while (true) {
        cap >> srcImage;//读取当前帧
        if (!srcImage.empty()) {
            //进行图像处理
            imageProcess(srcImage);
            logMode();//打印状态
            //show or send picture
            if (flag) {//
                colorgroup.showPicture(srcImage, 1);
                show_send_picture();
            }
        }
        //check any key ,then break out.
        //检测到键值，退出循环
        int len = read(STDIN_FILENO, &buf[0], 5);
        if (len > 0) {
            break;
        }
        //因为运动控制板最大接收频率14hz，故此处延迟70ms
        QThread::msleep(70);

    }
    mythread.setStop();
    QThread::msleep(200);
    lcmutil->send(LcmUtil::stop);
    printf("程序运行结束\n");
    cap.release();
    return 0;
}

void imageProcess(Mat &image){
    Mat ZoomOutimage,matEdges;
    Mat matHSV,Blurimage,transfered_black;
    int average = 0;
    //Mat transfered_black;
    resize(image,ZoomOutimage,Size(80,60));//改变图像尺寸为80*60

//    imshow("原图",ZoomOutimage);
//    waitKey(1);
//    imshow("灰度图",matGrey);
//    waitKey(1);
//    imshow("中值滤波图",matBlur);
//    waitKey(1);

    /***********get edge value**********/
    cvtColor(ZoomOutimage,matHSV,COLOR_BGR2HSV,0);//HSV图
//    cvtColor(ZoomOutimage,matGrey,COLOR_BGR2GRAY,0);//灰度图
    medianBlur(matHSV,Blurimage,3);//中值滤波
    inRange(Blurimage,colorgroup.blackMin,colorgroup.blackMax,transfered_black);//输出图像为单通道二值图
//        medianBlur(matHSV,matBlur,5);//中值滤波
    Canny(transfered_black,matEdges,150,255,3,true);//canny边缘检测

    if(nextColor=="blue"){
        Color_deal(Blurimage,colorgroup.blue);//blue
    }else if(nextColor=="green"){
        Color_deal(Blurimage,colorgroup.green);//green
    }else if(nextColor=="purple"){
        qDebug() << "Purple nnnnn" << endl;
        Color_deal(Blurimage,colorgroup.purple);//purple
    }else if(nextColor=="brown"){
        Color_deal(matHSV,colorgroup.brown);//brown
    }else if(nextColor=="null"){
        qDebug() << "Null: " << time_counter << endl;
        time_counter ++;
        if (time_counter > 10){
            nextColor = "brown";
            time_counter = 0;
        }
    }

    //the action of each thread defined here
    if (mythread.Mode == myThread::byroadA) {//left dash
        qDebug() << "TrackLeft" << endl;
        matHSV.setTo(cv::Scalar(0, 0, 0));
        nextColor = "null";
        lcmutil->send(0.35f, 0.00f, 0.60f, 0, 0, 148);
        QThread::sleep(2.3);
        mythread.Mode=myThread::track;

    }else if (mythread.Mode == myThread::byroadB) {
        qDebug() << "Right" << endl;
        nextColor = "purple";
        right();
        QThread::sleep(1.5);
        mythread.Mode=myThread::track;

    }else if (mythread.Mode == myThread::track) {
        qDebug() << "TrackMode" << endl;
        track_run(matEdges,matEdges);//边沿识别循迹


    }else if(mythread.Mode == myThread::lean_left){
        qDebug() << residenceColor<<"LLEFT\r" << endl;
        lcmutil->send(0.00f, 0.025f, 0.00f, 0, 0, 144);
        sleep(1.5);
        lcmutil->send(LcmUtil::lean_left);
        QThread::sleep(2);

        residenceColor == "purple";
        nextColor == "blue";
        mythread.Mode=myThread::track;

    }else if(mythread.Mode == myThread::lean_right){
        qDebug() << residenceColor<<"RRIGHT\r" << endl;
        lcmutil->send(LcmUtil::lean_right);
        QThread::sleep(3);
//        lcmutil->send(1.0f, 0.00f, 0.35f, 0, 0, 148);
//        QThread::sleep(1.2);
        residenceColor == "brown";
        nextColor == "blue";
        mythread.Mode=myThread::track;

    }else if(mythread.Mode == myThread::updais){
        qDebug() << "UP\r "<< endl;
        QThread::sleep(0.5);
        lcmutil->send(0.0f, 0.025f, 0.00f, 0, 0, 144);
        QThread::sleep(1);
        lcmutil->send(LcmUtil::updais);
        QThread::sleep(15);

        mythread.Mode=myThread::track;

    }else if(mythread.Mode == myThread::stop){
        qDebug() << "UP\r "<< endl;
        lcmutil->send(LcmUtil::stop);//发送停止指令
    }


//    }else if((mythread.Mode == myThread::step)){
//        while (!((average > 77.0f) || (average < 3.0f))){
//            qDebug() << "sgydigadgsdgai;gda;dg;siyydga;isdga;idgsai;dgai;dgasgdasidgia "<< endl;
//            qDebug() << "average: " << average << endl;
//            average = solve_avg(matEdges,matEdges);
//        }
//        if (residenceColor == "purple" ){
//            mythread.Mode = myThread::byroadB;
//        }else if (residenceColor == "brown"){
//            mythread.Mode = myThread::byroadA;
//        }

}

void right(){
    lcmutil->send(0.35f, 0.0f, -0.76f, 0, 0, 148);//右转
}

//循迹处理
void track_run(Mat &matBlur, Mat &matEdges){
    int number = 0;
    int average = 0;
    int sum = 0 /*rows = 0*/;
    int position[100] = {0};
    matBlur = matBlur;
    // /***********get edge value**********/
    // Canny(matBlur, matEdges, 150, 255, 3, true);//canny边缘检测

    //判断右侧边缘黑白分界
    for (int i = 59; i >= 0; i--) {//行
        for (int j = 79; j >= 0; j--) {
            if (matEdges.at<uchar>(i, j) == 255) {//像素点是白色
                position[i] = j;
                break;
            } else {
                position[i] = 0;
            }
        }
    }
    //计算平均值作为左转右转还是直行的依据
    for (int i = 0; i < matEdges.rows - 1; i++) {//59
        if ((position[i] < (position[i + 1] + 5)) &&
            (position[i] > (position[i + 1] - 5)) &&
            (position[i] != 0)) {
            sum = sum + position[i];
            number++;
        }
    }
//    qDebug()<<"sum"<< sum <<endl;
    if (sum == 0) {
        average = 80;
    } else {
        average = sum / number;
    }

//    qDebug() << "     right_zhongxin" << endl;
//    qDebug() << "average: " << average << endl;
//    qDebug() << "rows: " << rows << endl;
    //决赛采用中间循迹
    //中间循迹
    if ((average > 77.0f) || (average < 3.0f)) { //直行
        lcmutil->send(0.25f, 0, 0, 0, 0, 144);
//        qDebug() << "average<3.0 || average>77.0" << endl;

    } else if (average > 65.0f) {
        lcmutil->send(0.25f, -0.09f, 0.58f, 0, 0, 144);//右横移左转
//        qDebug() << "average>65.0" << endl;
    } else if (average > 48.0f) {
        lcmutil->send(0.25f, -0.09f, 0.58f, 0, 0, 144);//右横移左转
//        qDebug() << "average>48.0" << endl;

    } else if (average <= 40.0f) {

        lcmutil->send(0.25f, 0.1f, -0.80f, 0, 0, 144);//左横移右转
//        qDebug() << "左横移右转" << endl;
    } else {
        lcmutil->send(0.25f, -0.0f, 0.0f, 0, 0, 144);//右横移左转
//        qDebug() << "Other" << endl;
    }
}

//循迹处理_right
void track_run_right(Mat &matBlur, Mat &matEdges){
    int number = 0;
    int average = 0;
    int sum = 0;
    int position[100] = {0};

    matBlur = matBlur;

    /***********get edge value**********/
    // Canny(matBlur, matEdges, 150, 255, 3, true);//canny边缘检测
    //判断右侧边缘黑白分界
    for (int i = 59; i > 0; i--) {//行
        for (int j = 79; j > 0; j--) {
            if (matEdges.at<uchar>(i, j) == 255) {//像素点是白色
                position[i] = j;
                break;
            } else {
                position[i] = 0;
            }
        }
    }
    //计算平均值作为左转右转还是直行的依据
    average = 0;
    number = 0;
    sum = 0;
    for (int i = 0; i < matEdges.rows - 1; i++) {//59
        if ((position[i] < (position[i + 1] + 5)) && 
            (position[i] > (position[i + 1] - 5)) && 
            (position[i] != 0)) {
            sum = sum + position[i];
            number++;
        }
    }
//    qDebug()<<"sum"<< sum <<endl;
    if (sum == 0) {
        average = 80;
    } else {
        average = sum / number;
    }
//    qDebug() << "average: " << average << endl;
    //右边循迹
    if ((average > 75.99f)) {//未识别到边界
        lcmutil->send(0.15f, 0.01f, -0.45f, 0, 0, 144);//左横移右转
        qDebug() << "average>75.99" << endl;
    } else if (average >= 70) {
        lcmutil->send(0.15f, 0.05f, -0.35f, 0, 0, 144);//左横移右转
        qDebug() << "average>= 70" << endl;
    } else if (average >= 35) {
        lcmutil->send(0.15f, 0.06f, -0.30f, 0, 0, 144);//左横移右转
        qDebug() << "average>= 35" << endl;
    } else if (average >= 15) {
        lcmutil->send(0.15f, -0.1f, 0.25f, 0, 0, 144);//右横移左转
        qDebug() << "average>= 15" << endl;
    }
}

int solve_avg(Mat &matBlur, Mat &matEdges){
    int number = 0;
    int average = 0;
    int sum = 0;
    int position[100] = {0};
    matBlur = matBlur;
    for (int i = 59; i > 0; i--) {//行
        for (int j = 79; j > 0; j--) {
            if (matEdges.at<uchar>(i, j) == 255) {//像素点是白色
                position[i] = j;
                break;
            } else {
                position[i] = 0;
            }
        }
    }
    average = 0;
    number = 0;
    sum = 0;
    for (int i = 0; i < matEdges.rows - 1; i++) {//59
        if ((position[i] < (position[i + 1] + 5)) &&
            (position[i] > (position[i + 1] - 5)) &&
            (position[i] != 0)) {
            sum = sum + position[i];
            number++;
        }
    }
    if (sum == 0) {
        average = 80;
    } else {
        average = sum / number;
    }
    return average;
}

//循迹处理_left
void track_run_left(Mat &matBlur, Mat &matEdges) {
    int number = 0;
    int average = 0;
    int sum = 0;
    int position[100] = {0};
    matBlur = matBlur;
    //判断右侧边缘黑白分界
    for (int i = 59; i > 0; i--) {//行
        for (int j = 79; j > 0; j--) {
            if (matEdges.at<uchar>(i, j) == 255) {//像素点是白色
                position[i] = j;
                break;
            } else {
                position[i] = 0;
            }
        }
    }
    //计算平均值作为左转右转还是直行的依据
    average = 0;
    number = 0;
    sum = 0;
    for (int i = 0; i < matEdges.rows - 1; i++) {//59
        if ((position[i] < (position[i + 1] + 5)) &&
            (position[i] > (position[i + 1] - 5)) &&
            (position[i] != 0)) {
            sum = sum + position[i];
            number++;
        }
    }
//    qDebug()<<"sum"<< sum <<endl;
    if (sum == 0) {
        average = 80;
    } else {
        average = sum / number;
    }
//    qDebug() << "     zuo" << endl;
    qDebug() << "average: " << average << endl;
    //左边循迹
    if ((average > 77.0f) || (average < 3.0f)) { //直行
        lcmutil->send(0.0f, 0, 0, 0, 0, 144);
        qDebug() << "average<3.0 || average>77.0" << endl;

    } else if (average > 65.0f) {
        lcmutil->send(0.0f, -0.01f, 0.55f, 0, 0, 144);//右横移左转
        qDebug() << "average>65.0" << endl;
    } else if (average > 48.0f) {
        lcmutil->send(0.0f, -0.01f, 0.55f, 0, 0, 144);//右横移左转
        qDebug() << "average>48.0" << endl;

    } else if (average <= 40.0f) {

        lcmutil->send(0.0f, 0.01f, -0.80f, 0, 0, 144);//左横移右转
        qDebug() << "左横移右转" << endl;
    } else {
        lcmutil->send(0.0f, -0.0f, 0.0f, 0, 0, 144);//右横移左转
        qDebug() << "Other" << endl;
    }
}

//颜色识别处理
void Color_deal(Mat &img, int color) {
    Mat transformImage;
    int number1 = 0;
    switch (color) {
        case colorgroup.blue: //blue  ---上高台
            inRange(img, colorgroup.blueMin, colorgroup.blueMax, transformImage);//输出图像为单通道二值图
            for (int i = 0; i <= 59; i++) {//列
                for (int j = 0; j <= 79; j++) {//行
                    if (transformImage.at<uchar>(i, j) == 255) {
                        number1++;
                        break;
                    }
                }
            }
            qDebug() << "BLUE:" << number1 << endl;
            if (number1 >= 13) {
                qDebug() << "find BLUE";

                nextColor = "green";
                mythread.Mode = myThread::updais;
            }
        break;

        case colorgroup.red://red --
            inRange(img, colorgroup.redMin, colorgroup.redMax, transformImage);//输出图像为单通道二值图
            for (int i = 0; i <= 59; i++) {//列
                for (int j = 0; j <= 79; j++) {//行
                    if (transformImage.at<uchar>(i, j) == 255) {
                        number1++;
                        break;
                    }
                }
            }
            qDebug() << "RED:" << number1 << endl;
            if (number1 >= 15) {
                mythread.Mode = myThread::byroadB;
                nextColor = "purple";
            }
        break;

        case colorgroup.brown://brown -- 送快递2
            inRange(img, colorgroup.brownMin, colorgroup.brownMax, transformImage);//输出图像为单通道二值图
            for (int i = 0; i <= 59; i++) {//列
                for (int j = 0; j <= 79; j++) {//行
                    if (transformImage.at<uchar>(i, j) == 255) {
                        number1++;
                        break;
                    }
                }
            }
            qDebug() << "BROWN:" << number1 << endl;
            if (number1 >= 20) {
                qDebug() << "find BROWN";
                mythread.Mode = myThread::lean_left;
                residenceColor = "purple";
                nextColor = "blue";
//                nextColor = "green";
            }
        break;

        case colorgroup.purple://purple -- 送快递1
            inRange(img, colorgroup.purpleMin, colorgroup.purpleMax, transformImage);//输出图像为单通道二值图
            for (int i = 0; i <= 59; i++) {//列
                for (int j = 0; j <= 79; j++) {//行
                    if (transformImage.at<uchar>(i, j) == 255) {
                        number1++;
                        break;
                    }
                }
            }
            qDebug() << "PURPLE:" << number1 << endl;
            if (number1 >= 19) {
                qDebug() << "find PURPLE";
                residenceColor = "brown";
                nextColor = "blue";
//                nextColor = "green";
                mythread.Mode = myThread::lean_right;
//                mythread.Mode = myThread::track;
            }
        break;

        case colorgroup.green://green --
            inRange(img, colorgroup.greenMin, colorgroup.greenMax, transformImage);//输出图像为单通道二值图
            for (int i = 0; i <= 59; i++) {//列
                for (int j = 0; j <= 79; j++) {//行
                    if (transformImage.at<uchar>(i, j) == 255) {
                        number1++;
                        break;
                    }
                }
            }
            qDebug() << "GREEN:" << number1 << endl;
            if (number1 >= 20) {
                qDebug() << "find GREEN";
                if (residenceColor=="brown"){
                    nextColor == "null";
                    mythread.Mode = myThread::byroadA;
                }else if (residenceColor=="purple"){
                    nextColor == "purple";
                    mythread.Mode = myThread::byroadB;
//                mythread.Mode = myThread::step;
                }
            }
        break;

    }
}


//显示发送图片
void show_send_picture() {

    //first  parameter is imput image
    //second parameter is output destination
    //second parameter is 0 ,output destination is native computer
    //second parameter is 1 ,output destination is upper computer
    colorgroup.start();//thread1
    if (udpsocket.ifReceiveInfoFlag != 0) {
        switch (udpsocket.ifReceiveInfoFlag) {
            case 1://choose color and return this color threadhold
                std::cout << "choose color and return this color threadhold" << std::endl;
                colorgroup.chooseColor(udpsocket.color);
                colorgroup.sendColorThreadhold();
                colorgroup.ifRunContinueFlag = true;
                break;
            case 2://set color threadhold
                std::cout << "set color threadhold" << std::endl;
                colorgroup.setColorThreadhold(udpsocket.colorThreadhold);
                break;
            case 3://save color threadhold
                std::cout << "save color threadhold" << std::endl;
                colorgroup.save();
                break;
        }
        udpsocket.ifReceiveInfoFlag = 0;
        }
   }

//print current modesss
void logMode() {
    static int count = 0;
    count++;
    if (count % 20 == 1) {
        switch (mythread.Mode) {
            case myThread::residence:
                cout << "Mode:" << "residence" << endl;
                break;
            case myThread::track:
                cout << "Mode:" << "track" << endl;
                break;
            case myThread::lean_left:
                cout<<"Mode:"<<"lean_left"<<endl;
                break;
            case myThread::lean_right:
                cout<<"Mode:"<<"lean_right"<<endl;
                break;
            case myThread::updais:
                cout<<"Mode:"<<"updais"<<endl;
                break;
            case myThread::stop:
                cout << "Mode:" << "stop" << endl;
                break;
        }
        qDebug() << "nextColor:" << nextColor << endl;
//        qDebug()<<"roundNumber:"<<roundNumber<<endl;
//        qDebug()<<"residenceColor"<<residenceColor<<endl;
    }
}
